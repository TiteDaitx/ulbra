public class Ponteiro {
    public int posicao;
}
